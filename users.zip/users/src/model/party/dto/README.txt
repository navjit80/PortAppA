
Remember - ALWAYS include any new or changed class names in corresponding jaxb.index
Also ALWAYS include in persistance.xml file for JPA objects.