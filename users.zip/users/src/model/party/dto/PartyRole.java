package model.party.dto;

public enum PartyRole {

     UNDEFINED, SELLER, BUYER
    
}
