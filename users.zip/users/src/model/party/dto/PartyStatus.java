package model.party.dto;

public enum PartyStatus {

    ACTIVE, DISABLED
}
