package model.user.dto;

public enum UserRoles {

    ROLE_USER, ROLE_REST, ROLE_PARTY_ADMIN, ROLE_GLOBAL_ADMIN, ROLE_VIEWONLY

}
